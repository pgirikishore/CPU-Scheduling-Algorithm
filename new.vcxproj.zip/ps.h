#pragma once
#include"sjf.h"
#include<iostream>
using namespace std;
class ps:public sjf
{
public:
	ps();
	~ps();
	void put();
};

