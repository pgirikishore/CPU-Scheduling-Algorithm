#include "stdafx.h"
#include "sjf.h"


sjf::sjf()
{
}


sjf::~sjf()
{
}
void sjf::sort(int processes[],int bt[],int n)
{
	int temp;
	for (int i = 0;i<n;i++)
	{
		for (int j = 0;j<n - 1;j++)
		{
			if (bt[j]>bt[j + 1])
			{
				temp = bt[j];
				bt[j] = bt[j + 1];
				bt[j + 1] = temp;
			}
		}
	}
	findavgTime(processes, n, bt);
}

void sjf::sort(int processes[],int bt[],int p[], int n)
{
	int temp,temp1;
	for (int i = 0;i<n;i++)
	{
		for (int j = 0;j<n - 1;j++)
		{
			if (p[j]>p[j + 1])
			{
				temp = p[j];
				p[j] = p[j + 1];
				p[j + 1] = temp;
			 
				temp1 = bt[j];
				bt[j] = bt[j + 1];
				bt[j + 1] = temp1;
			}
		}
	}
	findavgTime(processes, n, bt);
}

void sjf::findWaitingTime(int processes[], int n,
	int bt[], int wt[])
{
	
	wt[0] = 0;

	
	for (int i = 1; i < n; i++)
		wt[i] = bt[i - 1] + wt[i - 1];
}




void sjf:: findavgTime(int processes[], int n, int bt[])
{
	int total_wt = 0, total_tat = 0;
	int *wt = new int[n];
	int *tat = new int[n];


	findWaitingTime(processes, n, bt, wt);


	findTurnAroundTime(processes, n, bt, wt, tat);


	cout << "Processes  " << " Burst time  "
		<< " Waiting time  " << " Turn around time\n";

	for (int i = 0; i<n; i++)
	{
		total_wt = total_wt + wt[i];
		total_tat = total_tat + tat[i];
		cout << "   " << i + 1 << "\t\t" << bt[i] << "\t    "
			<< wt[i] << "\t\t  " << tat[i] << endl;
	}

	cout << "Average waiting time = "
		<< (float)total_wt / (float)n;
	cout << "\nAverage turn around time = "
		<< (float)total_tat / (float)n;
	delete wt, tat;
}

void sjf::put()
{
	int processes[100], n;

	cout << "Enter the number of processes:";
	cin >> n;

	int burst_time[100];

	for (int i = 1;i <= n;i++)
	{
		processes[i] = i;
	}

	cout << "Enter the burst time" << endl;

	for (int i = 0;i < n;i++)
	{
		cout << i + 1 << ".";
		cin >> burst_time[i];
	}


	
	
	sort(processes, burst_time,n);
}